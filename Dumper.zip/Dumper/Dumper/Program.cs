﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SchemaDumper
{
    // Represents a single offset entry
    public class FieldOffset
    {
        public string Name { get; set; } = string.Empty;
        public string Offset { get; set; } = string.Empty;
    }

    // Represents a class, now simplified to just a container for offsets
    public class ClassSchema
    {
        public string Namespace { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public List<FieldOffset> Fields { get; } = new List<FieldOffset>();
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "ScheduleOne Offset Dumper (Final-Verified)";
            Console.WriteLine("Starting Finalized Offset Dumper...");

            string dumpFilePath = "dump.cs";
            if (!File.Exists(dumpFilePath))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Error: '{dumpFilePath}' not found. Please place it in the same directory as this executable.");
                Console.ResetColor();
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();
                return;
            }

            var fileContent = File.ReadAllLines(dumpFilePath);
            var schemas = new Dictionary<string, ClassSchema>();

            Console.WriteLine("\n[PASS 1/2] Parsing and merging all class definitions...");

            string currentNamespace = "Global";
            ClassSchema? currentSchema = null;

            var namespaceRegex = new Regex(@"^\s*// Namespace: (.*)");
            var classRegex = new Regex(@"^\s*(?:public|internal|private)\s+(?:sealed\s+)?(class|struct)\s+([\w`\d]+)");
            var fieldRegex = new Regex(@"^\s*(?:public|private|protected)\s+(?:const|static|readonly|volatile)?\s*[\w\.<>\[\]`\d]+\s+([\w<>`\.]+); // (0x[A-Fa-f0-9]+)");

            foreach (var line in fileContent)
            {
                var trimmedLine = line.Trim();
                if (string.IsNullOrEmpty(trimmedLine)) continue;

                var namespaceMatch = namespaceRegex.Match(trimmedLine);
                if (namespaceMatch.Success)
                {
                    var ns = namespaceMatch.Groups[1].Value.Trim();
                    currentNamespace = string.IsNullOrEmpty(ns) ? "Global" : Sanitize(ns);
                    continue;
                }

                var classMatch = classRegex.Match(trimmedLine);
                if (classMatch.Success)
                {
                    string className = Sanitize(classMatch.Groups[2].Value);
                    string fullKey = $"{currentNamespace}::{className}";

                    if (!schemas.TryGetValue(fullKey, out currentSchema))
                    {
                        currentSchema = new ClassSchema
                        {
                            Name = className,
                            Namespace = currentNamespace
                        };
                        schemas[fullKey] = currentSchema;
                    }
                    continue;
                }

                if (currentSchema != null)
                {
                    var fieldMatch = fieldRegex.Match(trimmedLine);
                    if (fieldMatch.Success)
                    {
                        var fieldName = Sanitize(fieldMatch.Groups[1].Value);
                        if (!currentSchema.Fields.Any(f => f.Name == fieldName))
                        {
                            currentSchema.Fields.Add(new FieldOffset { Name = fieldName, Offset = fieldMatch.Groups[2].Value });
                        }
                    }
                }
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nParsing complete. Found {schemas.Count} unique schemas.");
            Console.ResetColor();

            GenerateOffsetsHpp(schemas.Values.ToList());

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nGameSDK.hpp has been successfully generated!");
            Console.ResetColor();
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        static void GenerateOffsetsHpp(List<ClassSchema> schemas)
        {
            Console.WriteLine("\n[PASS 2/2] Generating final offsets header with syntax verification...");
            using (var writer = new StreamWriter("GameSDK.hpp"))
            {
                writer.WriteLine($"// Generated with Finalized Automated SDK Dumper");
                writer.WriteLine($"// Time: {DateTime.UtcNow}");
                writer.WriteLine("#pragma once");
                writer.WriteLine("#include <cstddef>");

                writer.WriteLine("\nnamespace sdk {");

                var groupedByNamespace = schemas
                    .Where(s => s.Fields.Any())
                    .GroupBy(s => s.Namespace)
                    .OrderBy(g => g.Key);

                foreach (var nsGroup in groupedByNamespace)
                {
                    writer.WriteLine($"    namespace {nsGroup.Key.Replace(".", "_")} {{");

                    foreach (var schema in nsGroup.OrderBy(s => s.Name))
                    {
                        writer.WriteLine($"        // Class: {schema.Name}");
                        writer.WriteLine($"        namespace {schema.Name} {{");

                        foreach (var field in schema.Fields.OrderBy(f => f.Name))
                        {
                            writer.WriteLine($"            constexpr std::ptrdiff_t {field.Name} = {field.Offset};");
                        }

                        writer.WriteLine("        }");
                    }

                    writer.WriteLine("    }");
                }

                writer.WriteLine("}");
            }
            Console.WriteLine("GameSDK.hpp generation complete.");
        }

        private static readonly HashSet<string> CppKeywords = new HashSet<string> {
            "alignas", "alignof", "and", "and_eq", "asm", "auto", "bitand", "bitor", "bool", "break", "case", "catch", "char", "char8_t", "char16_t", "char32_t",
            "class", "compl", "concept", "const", "consteval", "constexpr", "constinit", "const_cast", "continue", "co_await", "co_return", "co_yield",
            "decltype", "default", "delete", "do", "double", "dynamic_cast", "else", "enum", "explicit", "export", "extern", "false", "float", "for",
            "friend", "goto", "if", "inline", "int", "long", "mutable", "namespace", "new", "noexcept", "not", "not_eq", "nullptr", "operator", "or", "or_eq",
            "private", "protected", "public", "register", "reintepret_cast", "requires", "return", "short", "signed", "sizeof", "static", "static_assert",
            "static_cast", "struct", "switch", "synchronized", "template", "this", "thread_local", "throw", "true", "try", "typedef", "typeid", "typename",
            "union", "unsigned", "using", "virtual", "void", "volatile", "wchar_t", "while", "xor", "xor_eq", 
            // Add specific problematic identifiers here
            "_int32", "__int32", "int32", "interface", "near", "stdin", "stdout", "stderr"
        };

        public static string Sanitize(string name)
        {
            if (string.IsNullOrEmpty(name)) return "Unnamed";

            // Specific rule for __int32, as requested.
            if (name == "__int32") return "int32";

            string sanitized = name;

            // If the name is an exact match for a keyword, append an underscore.
            if (CppKeywords.Contains(sanitized))
            {
                return sanitized + "_";
            }

            // For other cases, replace invalid characters.
            sanitized = Regex.Replace(sanitized, @"[^\w\d_]", "_");

            if (string.IsNullOrEmpty(sanitized)) return "Unnamed_Identifier";

            // If the first character is a digit, prefix with an underscore.
            if (char.IsDigit(sanitized[0]))
            {
                sanitized = "_" + sanitized;
            }

            // Final check in case sanitization itself created a keyword.
            if (CppKeywords.Contains(sanitized))
            {
                sanitized += "_";
            }

            return sanitized;
        }
    }
}
